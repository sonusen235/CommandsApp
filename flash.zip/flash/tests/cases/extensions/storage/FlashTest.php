<?php
/**
 * flash plugin for Lithium: the most rad php framework.
 *
 * @copyright     Copyright 2010, Michael Hüneburg
 * @license       http://opensource.org/licenses/bsd-license.php The BSD License
 */

namespace flash\tests\cases\extensions\storage;

use flash\extensions\storage\Flash;
use \lithium\storage\Session;

class FlashTest extends \lithium\test\Unit {

	public function setUp() {
		Session::config(array(
			'default' => array(
				'adapter' => '\lithium\tests\mocks\storage\session\adapter\MockPhp'
			)
		));
	}
	
	public function tearDown() {
		Session::delete('FlashMessage');
	}
	
	public function testWrite() {
		Flash::write('Foo');
		$expected = array('message' => 'Foo', 'atts' => array());
		$result = Session::read('Flash.default', array('name' => 'default'));
		$this->assertEqual($expected, $result);
		
		Flash::write('Foo 2', array('type' => 'notice'));
		$expected = array('message' => 'Foo 2', 'atts' => array('type' => 'notice'));
		$result = Session::read('Flash.default', array('name' => 'default'));
		$this->assertEqual($expected, $result);
		
		Flash::write('Foo 3', array(), 'TestKey');
		$expected = array('message' => 'Foo 3', 'atts' => array());
		$result = Session::read('Flash.TestKey', array('name' => 'default'));
		$this->assertEqual($expected, $result);
	}
	
	public function testRead() {
		Flash::write('Foo');
		$expected = array('message' => 'Foo', 'atts' => array());
		$result = Flash::read();
		$this->assertEqual($expected, $result);
		
		Flash::write('Foo 2', array('type' => 'notice'));
		$expected = array('message' => 'Foo 2', 'atts' => array('type' => 'notice'));
		$result = Flash::read();
		$this->assertEqual($expected, $result);
		
		Flash::write('Foo 3', array(), 'TestKey');
		$expected = array('message' => 'Foo 3', 'atts' => array());
		$result = Flash::read('TestKey');
		$this->assertEqual($expected, $result);
	}
	
	public function testClear() {
		Flash::write('Foo');
		Flash::clear();
		$result = Session::read('Flash.default', array('name' => 'default'));
		$this->assertNull($result);
		
		Flash::write('Foo 2', array(), 'TestKey');
		Flash::clear('TestKey');
		$result = Session::read('Flash.TestKey', array('name' => 'default'));
		$this->assertNull($result);
		
		Flash::write('Foo 3', array(), 'TestKey2');
		Flash::write('Foo 4', array(), 'TestKey3');
		Flash::clear(null);
		$result = Session::read('Flash', array('name' => 'default'));
		$this->assertNull($result);
	}

}

?>
